package poo.app.burguerking;

import poo.app.burguerking.view.*;

public class Main {

	public static void main(String[] args) {
		MainGUI view = new MainGUI();
		view.MainGUI();
		view.setVisible(true);
	}
}