package poo.app.burguerking.config;

public class AppConfig {
		public final static String DB_USER = "root";
		public final static String DB_PASSWORD = "univille";
		public final static String DB_NAME = "burguerking";
		public final static String DB_PORT = "3307";
	}

