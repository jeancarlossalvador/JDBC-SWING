package poo.app.burguerking.dao;

import java.sql.DriverManager;

import poo.app.burguerking.config.AppConfig;

import java.sql.Connection;

public class DataBaseConnection {
	public Connection getConnection(){
		try{
			
			return DriverManager
					.getConnection("jdbc:mysql://localhost:"
							+ AppConfig.DB_PORT + "/" 
							+ AppConfig.DB_NAME + "?useSSL=false"
							, AppConfig.DB_USER
							, AppConfig.DB_PASSWORD);
			
		}catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
}


