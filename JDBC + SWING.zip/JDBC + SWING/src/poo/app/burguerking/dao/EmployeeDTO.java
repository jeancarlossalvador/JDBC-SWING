package poo.app.burguerking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import poo.app.burguerking.model.Employee;

public class EmployeeDTO {
	
private Connection connection;
	
	public EmployeeDTO() {
		this.connection = (new DataBaseConnection()).getConnection();
	}
	
	public boolean login(Employee employee) {
		String sql = "SELECT * FROM Employee WHERE CpfEmployee = ? AND PasswordEmployee = ?";
		try{
			this.connection = (new DataBaseConnection()).getConnection();
			
			PreparedStatement stmt = this.connection.prepareStatement(sql);

			stmt.setString(1, String.valueOf(employee.getCpf()));
			stmt.setString(2, employee.getPassword());
			
			ResultSet result = stmt.executeQuery();

			boolean resultBool = false;
			
			while (result.next()) {
				resultBool = true;
			}
			
			stmt.close();
			
			return resultBool;
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
}
