package poo.app.burguerking.dao;

import poo.app.burguerking.model.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductDTO {
	
private Connection connection;
	
	public ProductDTO() {
		this.connection = (new DataBaseConnection()).getConnection();
	}
	
	public List<Product> getProducts() {
		String sql = "SELECT * FROM Product";
		List<Product> products = new ArrayList<Product>();

		try{
			this.connection = (new DataBaseConnection()).getConnection();
			
			PreparedStatement stmt = this.connection.prepareStatement(sql);


			ResultSet result = stmt.executeQuery();

			while (result.next()) {
				Product product = new Product();
				product.setNome(result.getString("NameProduct"));
				product.setValor(result.getFloat("ValueProduct"));
				products.add(product);
			}
			
			stmt.close();
			
			return products;
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return products;
	}

}
