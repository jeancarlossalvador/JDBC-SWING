package poo.app.burguerking.model;

public class Product {
	

		private String nome;
		private float valor;
		
		public String getNome1() {
			return nome;
		}
		public void setNome1(String nome) {
			this.nome = nome;
		}
		public float getValor1() {
			return valor;
		}
		public void setValor1(float valor) {
			this.valor = valor;
		}
		

	public Object getNome() {
		return null;
	}

	public Object getValor() {
		return null;
	}

	public void setNome(String string) {
		
		
	}

	public void setValor(float float1) {
		
	}
	
  }
	

