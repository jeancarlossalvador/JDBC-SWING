package poo.app.burguerking.view;

import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.sun.nio.file.SensitivityWatchEventModifier;

import poo.app.burguerking.dao.EmployeeDTO;
import poo.app.burguerking.dao.ProductDTO;
import poo.app.burguerking.model.Employee;
import poo.app.burguerking.model.Product;
import poo.app.burguerking.model.ProductsTableModel;

public class MainGUI extends JFrame {
	private static final long serialVersionUID = 1L;
	private JTextField userField;
	private JPasswordField passwordField;
	private JPanel panel;

	public MainGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setTitle("Main Window");
		setSize(400, 400);

		setupPanel();
		setupFields(this.panel);
		setupLabels(this.panel);
		setupButton(this.panel);
	}

	private void setupPanel() {
		this.panel = new JPanel();

		ImageIcon image = new ImageIcon("C:/Users/eduarda.silva/workspace/JDBC + SWING/assets/logo.png");
		JLabel wIcon = new JLabel(image);
		wIcon.setBounds(20, 10, 350, 50);
		panel.add(wIcon);

		panel.setLayout(null);
		add(panel);
	}	

	private void setupFields(JPanel panel) {
		this.userField = new JTextField();
		this.userField.setBounds(150, 70, 200, 30);
		this.userField.setBorder(null);

		this.passwordField = new JPasswordField();
		this.passwordField.setBounds(150, 110, 200, 30);
		this.passwordField.setBorder(null);

		panel.add(this.passwordField);
		panel.add(this.userField);
	}

	private void setupLabels(JPanel panel) {
		JLabel userLabel = new JLabel("CPF", JLabel.CENTER);
		JLabel passwordLabel = new JLabel("Senha", JLabel.CENTER);

		userLabel.setBounds(50, this.userField.getY() + 5, 60, 20);
		passwordLabel.setBounds(50, this.passwordField.getY() + 5, 60, 20);

		panel.add(userLabel);
		panel.add(passwordLabel);
	}

	private void setupButton(JPanel panel) {
		JButton button = new JButton("Entrar");

		panel.add(button);

		button.setBounds(100, this.passwordField.getY() + this.passwordField.getHeight() + 40, 200, 40);
		button.setBorder(null);

		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(java.awt.event.ActionEvent arg0) {
				Employee employee = new Employee();

				employee.setCpf(new String(userField.getText()));
				employee.setPassword(new String(passwordField.getPassword()));

				EmployeeDTO empl = new EmployeeDTO(); 

				if (empl.login(employee)) {
					System.out.println(employee.getCpf());
					presentMainScreen();
				}
			}
		});
	}
	
	private void presentMainScreen() {
		JPanel panel = new JPanel();

		this.panel.setVisible(false);
		
		this.getContentPane().remove(this.panel);
		
		panel.setSize(1500, 968);
		this.panel.add(panel);
		add(panel);
		panel.setVisible(true);
		
		JLabel label = new JLabel("Bem Vindo", JLabel.CENTER);
		
		panel.add(label);
		
		ProductDTO productsDTO = new ProductDTO();
		
		List<Product> products = productsDTO.getProducts();
		
		
		ProductsTableModel tableModel = new ProductsTableModel();
		tableModel.setColumnNames(new String[]{"Nome","Valor"});
		
		Object[][] data = new Object[products.size()][2];
		
		for (int i=0; i < products.size() ; i++) {
			data[i][0] = products.get(i).getNome();
			data[i][1] = products.get(i).getValor();
		}

		tableModel.setData(data);
		
		
		JTable table = new JTable(tableModel);
		JScrollPane scrollPane = new JScrollPane(table);
		
		panel.setSize(this.getWidth(), this.getHeight());
		panel.add(scrollPane);
		
	}

	public void MainGUI() {
		
		
	}
}
