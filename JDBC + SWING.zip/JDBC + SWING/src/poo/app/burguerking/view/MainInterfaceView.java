package poo.app.burguerking.view;

import javax.swing.JFrame;

public class MainInterfaceView {
	public void setMainInterface() {
		JFrame window = new JFrame();
		
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setTitle("Burguer King �");
		window.setSize(400, 400);
		window.setVisible(true);
	}
}